export const serviceUrl = "http://localhost:3000";

export const maggie = {
    firstName: "Maggie",
    lastName: "Simpson",
    email: "maggie@simpson.com",
    password: "secret",
  };

export const testUsers = [
    {
      firstName: "Homer",
      lastName: "Simpson",
      email: "homer@simpson.com",
      password: "secret",
    },
    {
      firstName: "Marge",
      lastName: "Simpson",
      email: "marge@simpson.com",
      password: "secret",
    },
    {
      firstName: "Bart",
      lastName: "Simpson",
      email: "bart@simpson.com",
      password: "secret",
    }
];

    export const dublin = {
        title: "Favourite Dublin Bridges"
      };
      
      export const cork = {
        title: "Favourite Cork Bridges"
      };

      export const suspension = {
        "bridgename": "Grattan Bridge",
        "location": "Cork",
        "bridgetype": "suspension"
      };
      

      export const testBridgelists = [
        {
          title: "Clare Bridges"
        },
        {
          title: "Dublin Bridges"
        },
        {
          title: "Cork Bridges"
        }
      ];

      export const testBridges = [
        {
          "bridgename": "South Bridge",
          "location": "Dublin",
          "bridgetype": "Suspension Bridge"
        },
        {
          "bridgename": "North Bridge",
          "location": "Dublin",
          "bridgetype": "Cantilever Bridge"
        },
        {
          "bridgename": "East Bridge",
          "location": "Dublin",
          "bridgetype": "Truss Bridge"
        }
      ];

